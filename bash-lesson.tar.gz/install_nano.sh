#!/bin/bash

# Install nano in Git Bash on Windows
cd ~
curl -L -O https://www.nano-editor.org/dist/v2.5/NT/nano-2.5.3.zip
unzip nano-2.5.3.zip -d .nano
rm nano-2.5.3.zip
echo "alias nano='winpty ~/.nano/nano-2.5.3-win32/nano.exe'" >> .bash_profile
# Students should close this Git Bash session, then start a new one.
# They can then start nano with "nano"!

